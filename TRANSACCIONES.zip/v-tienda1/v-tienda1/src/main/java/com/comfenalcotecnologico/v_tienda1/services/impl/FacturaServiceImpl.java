package com.comfenalcotecnologico.v_tienda1.services.impl;

import com.comfenalcotecnologico.v_tienda1.models.DTOS.FacturaDTO;
import com.comfenalcotecnologico.v_tienda1.models.entities.Factura;
import com.comfenalcotecnologico.v_tienda1.models.entities.Producto;
import com.comfenalcotecnologico.v_tienda1.repositories.FacturaRepository;
import com.comfenalcotecnologico.v_tienda1.repositories.ProductoRepository;
import com.comfenalcotecnologico.v_tienda1.services.FacturaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class FacturaServiceImpl implements FacturaService {

    @Autowired
    private FacturaRepository facturaRepository;

    @Autowired
    private ProductoRepository productoRepository;

    @Override
    @Transactional
    public Factura crearFactura(FacturaDTO facturaDTO) {
        try {
            List<Producto> productos = facturaDTO.getProductoIds().stream()
                    .map(id -> productoRepository.findById(id).orElseThrow(() -> new RuntimeException("Producto no encontrado")))
                    .collect(Collectors.toList());

            Factura factura = new Factura();
            factura.setProductos(productos);
            factura.setTotal(productos.stream().mapToDouble(Producto::getPrecio).sum());

            // Simulando un fallo
            if (productos.size() > 3) {
                throw new RuntimeException("Simulando un fallo para la transacción.");
            }

            return facturaRepository.save(factura);
        } catch (Exception e) {
            // Si ocurre una excepción, la transacción será revertida
            throw new RuntimeException("Error al crear la factura: " + e.getMessage());
        }
    }
}