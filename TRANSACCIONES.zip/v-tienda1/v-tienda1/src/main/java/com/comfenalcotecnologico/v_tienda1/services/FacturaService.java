package com.comfenalcotecnologico.v_tienda1.services;

import com.comfenalcotecnologico.v_tienda1.models.DTOS.FacturaDTO;
import com.comfenalcotecnologico.v_tienda1.models.entities.Factura;

public interface FacturaService {
    Factura crearFactura(FacturaDTO facturaDTO);
}