package com.comfenalcotecnologico.v_tienda1.repositories;

import com.comfenalcotecnologico.v_tienda1.models.entities.Producto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductoRepository extends JpaRepository<Producto, Long> {
}