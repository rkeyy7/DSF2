package com.comfenalcotecnologico.v_tienda1.services;

import com.comfenalcotecnologico.v_tienda1.models.entities.Producto;
import com.comfenalcotecnologico.v_tienda1.repositories.ProductoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface ProductoService {
    List<Producto> obtenerTodos();
    Producto obtenerPorId(Long id);
}