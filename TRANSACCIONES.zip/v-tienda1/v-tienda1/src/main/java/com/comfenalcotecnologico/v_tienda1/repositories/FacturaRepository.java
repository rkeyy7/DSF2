package com.comfenalcotecnologico.v_tienda1.repositories;

import com.comfenalcotecnologico.v_tienda1.models.entities.Factura;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FacturaRepository extends JpaRepository<Factura, Long> {
}