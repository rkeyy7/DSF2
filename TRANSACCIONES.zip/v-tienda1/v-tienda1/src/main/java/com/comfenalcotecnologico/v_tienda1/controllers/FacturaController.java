package com.comfenalcotecnologico.v_tienda1.controllers;

import com.comfenalcotecnologico.v_tienda1.models.DTOS.FacturaDTO;
import com.comfenalcotecnologico.v_tienda1.models.entities.Factura;
import com.comfenalcotecnologico.v_tienda1.services.FacturaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/facturas")
public class FacturaController {

    @Autowired
    private FacturaService facturaService;

    @PostMapping
    public ResponseEntity<Factura> crearFactura(@RequestBody FacturaDTO facturaDTO) {
        Factura factura = facturaService.crearFactura(facturaDTO);
        return ResponseEntity.ok(factura);
    }
}