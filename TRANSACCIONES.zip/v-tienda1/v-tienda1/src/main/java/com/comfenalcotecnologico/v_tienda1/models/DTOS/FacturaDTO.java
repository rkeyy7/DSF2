package com.comfenalcotecnologico.v_tienda1.models.DTOS;


import lombok.*;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class FacturaDTO {
    private List<Long> productoIds;
}