package com.comfenalcotecnologico.v_tienda1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VTienda1Application {

	public static void main(String[] args) {
		SpringApplication.run(VTienda1Application.class, args);
	}

}
