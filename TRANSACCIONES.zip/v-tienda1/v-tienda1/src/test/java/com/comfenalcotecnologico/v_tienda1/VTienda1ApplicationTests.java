package com.comfenalcotecnologico.v_tienda1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VTienda1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
