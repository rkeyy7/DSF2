package com.cachorritoscol.cachorritosctg.cachorritosctg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CachorritosctgApplicationTests {

	@Test
	void contextLoads() {
	}

}
