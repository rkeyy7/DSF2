package com.cachorritoscol.cachorritosctg.cachorritosctg.mascotas.controllers;

import com.cachorritoscol.cachorritosctg.cachorritosctg.mascotas.models.dtos.CategoryDTO;
import com.cachorritoscol.cachorritosctg.cachorritosctg.mascotas.services.CategoryService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class CategoryController {
    private final CategoryService categoryService;

    public CategoryController(CategoryService categoryService) {
        this.categoryService = categoryService;
    }

    @PostMapping("category")
    public void create(CategoryDTO categoryDTO){
        categoryService.create(categoryDTO);
    }
    @GetMapping("category")
    public List<CategoryDTO> findAll(){
        return categoryService.findALL();
    }
}
