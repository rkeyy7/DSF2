package com.cachorritoscol.cachorritosctg.cachorritosctg.mascotas.services;

import com.cachorritoscol.cachorritosctg.cachorritosctg.mascotas.models.dtos.PetDTO;

import java.util.List;

public interface PetService {
    List<PetDTO> findALL();
}
