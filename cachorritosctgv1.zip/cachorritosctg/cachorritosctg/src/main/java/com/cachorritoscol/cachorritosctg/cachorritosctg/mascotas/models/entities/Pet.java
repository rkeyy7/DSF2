package com.cachorritoscol.cachorritosctg.cachorritosctg.mascotas.models.entities;


import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class Pet {

    private int id;
    private String name;
    private int quantity;
    private float price;
    private List<Category> categories;
}
