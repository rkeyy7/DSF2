package com.cachorritoscol.cachorritosctg.cachorritosctg.mascotas.models.dtos;

import com.cachorritoscol.cachorritosctg.cachorritosctg.mascotas.models.entities.Category;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class PetDTO {
    private String name;
    private int quantity;
    private float price;
    private List<Category> categories;
}
