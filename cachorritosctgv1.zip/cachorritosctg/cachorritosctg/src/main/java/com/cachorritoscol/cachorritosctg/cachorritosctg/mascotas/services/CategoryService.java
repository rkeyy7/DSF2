package com.cachorritoscol.cachorritosctg.cachorritosctg.mascotas.services;

import com.cachorritoscol.cachorritosctg.cachorritosctg.mascotas.models.dtos.CategoryDTO;

import java.util.List;

public interface CategoryService {
    void create(CategoryDTO category);
    List<CategoryDTO> findALL();
}
