package com.cachorritoscol.cachorritosctg.cachorritosctg.mascotas.services.impl;

import com.cachorritoscol.cachorritosctg.cachorritosctg.mascotas.models.dtos.PetDTO;
import com.cachorritoscol.cachorritosctg.cachorritosctg.mascotas.services.PetService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PetServiceImpl implements PetService {
    @Override
    public List<PetDTO> findALL(){return List.of();}
}
