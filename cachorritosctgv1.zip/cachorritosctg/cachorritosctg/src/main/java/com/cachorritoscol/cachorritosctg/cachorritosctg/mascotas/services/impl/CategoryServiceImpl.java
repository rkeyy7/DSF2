package com.cachorritoscol.cachorritosctg.cachorritosctg.mascotas.services.impl;

import com.cachorritoscol.cachorritosctg.cachorritosctg.mascotas.models.dtos.CategoryDTO;
import com.cachorritoscol.cachorritosctg.cachorritosctg.mascotas.services.CategoryService;

import java.util.Arrays;
import java.util.List;

public class CategoryServiceImpl  implements CategoryService {
    @Override
    public void create(CategoryDTO category) {
        System.out.println("Crear");
    }

    @Override
    public List<CategoryDTO> findALL() {
        List<CategoryDTO> list= Arrays
                .asList(
                        new CategoryDTO("bulldog","kevin","Perro"),
                        new CategoryDTO("bulldog","kevin","Perro"),
                        new CategoryDTO("bulldog","kevin","Perro")
                );
        return list;
    }
}
