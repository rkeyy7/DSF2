package com.cachorritoscol.cachorritosctg.cachorritosctg.mascotas.models.entities;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Category {
    private int id;
    private String race;
    private String name;
    private String species ;


}
