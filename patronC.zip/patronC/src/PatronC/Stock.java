package PatronC;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author AERO COOL
 */
public class Stock {
	
   private String nombre = "ABC";
   private int cantidad = 10;

   public void comprar(){
      System.out.println("Stock [ Nombre: "+nombre+", Cantidad: " + cantidad +" ] compro");
   }
   public void vender(){
      System.out.println("Stock [ Nombre: "+nombre+", Cantidad: " + cantidad +" ] vendio");
   }
}


